# simple terminal login application
# default name = Lass
# default password = helloworld
# at least have python ver. 3.10 interpreter installed

import random
import sys


print("\033[1;32mWelcome back! Please enter your account details.")
name = ""
password = ""
newName = ""
newPassword = ""
while name != "Lass" and password != "helloworld":
    name = input("\033[0;97mEnter Username: ")
    password = input("Enter Password: ")
    if name != "Lass" or password != "helloworld":
        print()
        print("Wrong credentials, ending process", file=sys.stderr)
        sys.exit()
    elif name == "" and password == "":
        print()
        print("Wrong credentials, ending process", file=sys.stderr)

# if login successful
print()
print("Welcome, "+name)

while True:
    print()
    decision = input("\033[1;32m>>> What would you like to do? (/help for commandlist): ")

    match decision:
        # logout
        case "/leave":
            print("\033[0;97mExiting application...")
            sys.exit()

        # add new account
        case "/addaccount":
            while newName == "" and newPassword == "":
                newName = input("\033[0;97mEnter a new Username: ")
                newPassword = input("Enter a new Password: ")
            print("\033[0;93mNew account created! Welcome, " + newName +".")
            print("\033[0;97m")

        # generate random number
        case "/randomnumber":
            rangeFrom = input("\033[0;97mRandom number between (select starting value): ")
            rangeTo = input("To (select end value): ")
            randomNumber = random.randint(int(rangeFrom), int(rangeTo))
            print("Generated number: " + str(randomNumber))
            print("\033[0;97m")


        # add new info
        case "/addinfo":
            birthDate = input("\033[0;97mWhen were you born?\033[0;93m (eg. 1.5.1996): ")
            birthPlace = input("\033[0;97mWhere were you born?: ")
            currentAddress = input("Where do you live now?: ")
            isStudent = input("Are you a student? (Yes/No): ")
            print("\033[0;93mYou were born on the " + birthDate + "\033[0;93m, your birthplace is " + birthPlace +
                  "\033[0;93m. You currently live in " + currentAddress +
                  "\033[0;93m and you are a student: " + isStudent)
            print("\033[0;97m")

        # show default account and created account
        case "/showacc":
            print("\033[0;97m1) " + name + " (password: " + password + ")")
            if newName != "":
                print("\033[0;97m1) " + newName + " (password: " + newPassword + ")")
            print("\033[0;97m")

        # help
        case "/help":
            print("\033[0;97m/leave, /addaccount, /randomnumber, /addinfo, /showacc")
            print()

        # default input
        case _:
            print()
            print("\033[0;97mThat is not a valid request!")
            print()